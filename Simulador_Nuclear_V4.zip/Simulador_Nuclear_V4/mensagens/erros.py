class quadratura_impar(Exception):
    pass


class nodo_zero(Exception):
    pass


class espessura_zero(Exception):
    pass


class regiao_invalida(Exception):
    pass


def detectar_erros(sigmaT, N, NN, regioes, esp_R):
    if N % 2 != 0:
        raise quadratura_impar("O Valor digitado para quadratura é ímpar.")

    for nodo in NN:
        if nodo <= 0:
            raise nodo_zero("O número de nodos digitado é menor ou igual a zero.")

    for espessura in esp_R:
        if espessura <= 0:
            raise espessura_zero("A espessura da região deve ser maior que zero.")

    for regiao in regioes:
        if regiao < 1 or regiao > len(sigmaT):
            raise regiao_invalida(
                f"O número da região está fora das regiões permitidas [1:{len(sigmaT)}]"
            )
